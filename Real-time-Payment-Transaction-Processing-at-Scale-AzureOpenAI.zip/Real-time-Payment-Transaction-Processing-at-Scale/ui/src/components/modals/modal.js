const Modal = () => {
  return <></>;
};

export default Modal;
